<?php 
// echo "<div class='wrapper'>
// 	<ul class='right'>";
// 		$topmenu2 = $this->model_utama->view_where('menu',array('position' => 'Top','aktif' => 'Ya'),'urutan','ASC',0,5);
// 			foreach ($topmenu2->result_array() as $row) {
// 			echo "<li><a href='$row[link]'>$row[nama_menu]</a></li>";
// 		}
// 	echo "</ul>
// 	<p class='footer'>Copyright &copy;".date('Y').". All Rights reserved.<br/>Powered by <b style='color:salmon'><a href='http://www.401xd.com'>Kemanisan</a></b></p>
// </div>";
 ?>


             <div class="wrapper">
             <div class="row">
                 <div class="col-md-5">
                     <h4 class="text-warning">Kemanisan</h4>
                     <p class="text-white mt-4">Kemanisan adalah aplikasi jual beli gula merah berbasis web, semua produsen gula merah yang bergabung bersama kami, bisa menjual dan mempromosikan produk mereka disini, kami juga akan memberikan informasi penting yang berkaitan dengan industri ini, jangan takut mencoba bisnis ini dan jadilah agen gula merah yang sukses bersama kami, karna kami selalu memberikan saran dan masukkan di program mentor dan diskusi.</p>
                 </div>
                 <div class="col-md-2">
                     <h4 class="text-warning">Member Of Team</h4>
                     <p class="text-white"><a href="https://www.instagram.com/faizmuazzam_/" target="_blank" class="text-white"> <img src="<?= base_url(); ?>/asset/icon/instagram.png" width="15px" class=""> @faizmuazzam_</a></p>
                     <p class="text-white"><a href="https://www.instagram.com/naufalsa__/" target="_blank" class="text-white"> <img src="<?= base_url(); ?>/asset/icon/instagram.png" width="15px" class=""> @naufalsa__</a></p>
                     <p class="text-white"><a href="https://www.instagram.com/prisca_anggita/" target="_blank" class="text-white"> <img src="<?= base_url(); ?>/asset/icon/instagram.png" width="15px" class=""> @prisca_anggita</a></p>
                     <p class="text-white"><a href="" target="_blank" class="text-white"> <img src="<?= base_url(); ?>/asset/icon/instagram.png" width="15px" class=""> @ansysftr</a></p>
                 </div>
                 <div class="col-md-4">

                     <h4 class="text-warning">Contact Us</h4>
                     <div class="left">
                        <script language="javascript">
                        document.write("<a href='" + document.URL + " ' target='_blank' class='custom-soc icon-text'>&#62220;</a> <a href='" + document.URL + "' target='_blank' class='custom-soc icon-text'>&#62217;</a> <a href='" + document.URL + "' target='_blank' class='custom-soc icon-text'>&#62223;</a>");
                        </script>
                    </div>
                 </div>
             </div>
             <hr>
             <div class="row">
                <div class="col-12">
                    <a href=""><p class="footer">&copy; Copyright 2018 Kemanisan - Always Break The Limit</p></a>
                </div>
            </div>
         </div>
